cd ..
make clean
make
./sr -s 1234 -w 50 -m 20 -l 0.1 -c 0.2 -t 50 -v 10
